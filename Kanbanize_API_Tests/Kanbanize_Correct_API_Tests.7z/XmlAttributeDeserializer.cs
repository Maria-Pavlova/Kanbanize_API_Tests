﻿namespace Kanbanize_API_Tests
{
    internal class XmlAttributeDeserializer
    {
        public XmlAttributeDeserializer()
        {
        }
    }
}