﻿namespace Kanbanize_API_Tests
{
    public class Task
    {
        public int taskid { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public string columnname { get; set; }
        public string priority { get; set; }
    }
}