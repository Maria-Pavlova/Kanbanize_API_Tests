
using NUnit.Framework;
using RestSharp;
using System.Net;


namespace Kanbanize_API_Tests
{
    public class KanbanizeTests
    {
        const string BaseUrl = "https://job.kanbanize.com/index.php/api/kanbanize";
        private RestClient client;
        private RestRequest request;

        [SetUp]
        public void Setup()
        {

            this.client = new RestClient();
        }

        [Test, Order(1)]
        public void Test_Create_Valid_Card()
        {
            request = new RestRequest(BaseUrl + "/create_new_task/", Method.Post);
            request.AddHeader("apikey", "KFUHGLAV3H6aP9RSfsUsxmKmnkVuKm8zQyXbMAx7");

            var body = new
            {
                boardid = "1",
                title = "Test task by VS",
                description = "task description",
                priority = "High",
                assignee = "Maria",
                tags = "tag1 tag2",
                deadline = "2022-06-24",
                column = "Requested",
                position = "1"
            };

            request.AddJsonBody(body);
            var response = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);

        }

           

        [Test, Order(2)]
        public void Test_Check_Card_Details()
        {
            request = new RestRequest(BaseUrl + "/get_task_details/", Method.Post);
            request.AddHeader("apikey", "KFUHGLAV3H6aP9RSfsUsxmKmnkVuKm8zQyXbMAx7");

            var body = new
            {
                boardid = "1",
                taskid = "16",

            };
            request.AddJsonBody(body);
            var response = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
                                   
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            StringAssert.Contains("Test task by VS", response.Content);
            StringAssert.Contains("task description", response.Content );
            StringAssert.Contains("High", response.Content);
            StringAssert.Contains("Requested", response.Content);
        
        }

        [Test, Order(3)]
        public void Test_Move_Card()
        {
            request = new RestRequest(BaseUrl + "/create_new_task/", Method.Post);
            request.AddHeader("apikey", "KFUHGLAV3H6aP9RSfsUsxmKmnkVuKm8zQyXbMAx7");

            var body = new
            {
                boardid = "1",
                taskid = "16",
                column = "In Progress"
            };

            request.AddJsonBody(body);
            var response = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
        }

        [Test, Order(4)]
        public void Test_Delete_Task()
        {
            request = new RestRequest(BaseUrl + "/delete_task/", Method.Post);
            request.AddHeader("apikey", "KFUHGLAV3H6aP9RSfsUsxmKmnkVuKm8zQyXbMAx7");

            var body = new
            {
                boardid = "1",
                taskid = "16"

            };

            request.AddJsonBody(body);
            var response = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);

        }


        [Test, Order(5)]
        public void Test_Check_Card_Deleted()
        {
            request = new RestRequest(BaseUrl + "/get_task_details/", Method.Post);
            request.AddHeader("apikey", "KFUHGLAV3H6aP9RSfsUsxmKmnkVuKm8zQyXbMAx7");

            var body = new
            {
                boardid = "1",
                taskid = "16",

            };

            request.AddJsonBody(body);
            var response = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.BadRequest, response.StatusCode);
            Assert.That(response.Content.Contains("The specified task does not exist."));
        }
    }
}